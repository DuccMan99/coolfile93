function love.load()
logo = love.graphics.newImage("logow.png")
end

function love.draw()
  love.graphics.print('Windows93.net', 20, 10)
  love.graphics.draw(logo, 50, 10)
end

function love.keypressed(key)
  if key == "escape" then
    love.event.quit()
  end
end